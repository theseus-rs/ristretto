import java.lang.ref.WeakReference;
public final class GcBench {
    static long sum;
    static WeakReference<Object[]> witness;
    static void allocate(int i) {
        Object[] value = new Object[4097];
        sum += value.length;
        if (i == 0 || i == 200) witness = new WeakReference<Object[]>(value);
    }
    public static void main(String[] args) {
        int total=Integer.parseInt(args[2]); int i=0;
        try {
            for(;i<total;++i) allocate(i);
        } catch(OutOfMemoryError err) {
            System.out.println("first failure at " + i + " weak cleared " + (witness.get()==null));
            for (int j=0;j<5;j++) {
                System.gc();
                try {Thread.sleep(100);} catch(Exception ignored) {}
                try {allocate(-1);System.out.println("retry succeeded "+j+" weak cleared "+(witness.get()==null));return;}
                catch(OutOfMemoryError retry) {System.out.println("retry failed "+j+" weak cleared "+(witness.get()==null));}
            }
            throw err;
        }
        System.out.println("completed " + i);
    }
}
