public final class GcBench {
    static Object[] retained = new Object[32];
    static final Object marker = new Object();
    static volatile int checksum;
    public static void main(String[] args) {
        int mode = Integer.parseInt(args[1]);
        int count = Integer.parseInt(args[2]);
        int i=0;
        try {
            for (; i<count; ++i) {
                if (mode==4) { byte[] bytes=new byte[131104]; checksum+=bytes.length; continue; }
                Object[] array=new Object[4097];
                checksum+=array.length;
                if ((mode&1)!=0) {array[0]=marker;array[4096]=marker;}
                if ((mode&2)!=0) retained[i&31]=array;
            }
            System.out.println("completed " + i);
        } catch(OutOfMemoryError error) {
            System.out.println("failed at " + i); throw error;
        }
    }
}
