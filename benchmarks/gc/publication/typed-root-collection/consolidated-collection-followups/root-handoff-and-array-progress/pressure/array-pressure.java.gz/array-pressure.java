public final class GcBench {
    static Object[] retained = new Object[32];
    static final Object marker = new Object();
    public static void main(String[] args) {
        int length = Integer.parseInt(args[1]);
        int iterations = Integer.parseInt(args[2]);
        int collectEvery = Integer.parseInt(args[3]);
        int i = 0;
        try {
            for (; i < iterations; ++i) {
                Object[] array = new Object[length];
                array[0] = marker;
                array[length - 1] = marker;
                retained[i & 31] = array;
                if (collectEvery > 0 && (i + 1) % collectEvery == 0) System.gc();
            }
            System.out.println("completed " + i);
        } catch (OutOfMemoryError failure) {
            System.out.println("failed at " + i);
            throw failure;
        }
    }
}
