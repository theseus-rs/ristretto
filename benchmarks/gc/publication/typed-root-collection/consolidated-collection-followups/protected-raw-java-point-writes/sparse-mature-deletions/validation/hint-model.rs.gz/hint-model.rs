
#[cfg(all(not(target_family="wasm"),not(miri)))]
#[test]
fn stale_parent_hint_races_a_new_leaf() {
    use loom::sync::Arc as Shared;
    use loom::sync::atomic::{AtomicBool, AtomicUsize};
    let skip = std::env::var_os("GC_SKIP_SAME_PARENT_RMW").is_some();
    loom::model(move || {
        let root = Shared::new(AtomicUsize::new(1)); // legitimate stale hint
        let leaf = Shared::new(AtomicUsize::new(0));
        let consumed = Shared::new(AtomicBool::new(false));
        let (p,c)=(root.clone(),leaf.clone());
        let writer=loom::thread::spawn(move || {
            c.fetch_or(1, Ordering::AcqRel);
            if !skip || p.load(Ordering::Acquire) & 1 == 0 {
                p.fetch_update(Ordering::AcqRel, Ordering::Acquire, |prior| (prior & 2 == 0).then_some(prior|1)).unwrap();
            }
        });
        let (p,c,seen)=(root.clone(),leaf.clone(),consumed.clone());
        let claimant=loom::thread::spawn(move || {
            if p.fetch_and(!1,Ordering::AcqRel)&1 != 0 {
                if c.load(Ordering::Acquire)&1 != 0 && c.fetch_and(!1,Ordering::AcqRel)&1 != 0 {seen.store(true,Ordering::Release);}
                if c.load(Ordering::Acquire)&1 != 0 {p.fetch_or(1,Ordering::Release);}
            }
        });
        writer.join().unwrap();claimant.join().unwrap();
        let closed=root.compare_exchange(0,2,Ordering::AcqRel,Ordering::Acquire).is_ok();
        assert!(!closed || consumed.load(Ordering::Acquire),"sealed over completed publication");
    });
}
