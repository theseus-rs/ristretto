//! Experiment for a future handoff from the mature deletion bitmap.
//! One parity lane, one strong target and two helpers. Real graph tracing,
//! contested addresses, cross-generation closure and other work are excluded.
#![cfg(not(target_family = "wasm"))]
use Ordering::{AcqRel, Acquire, Release};
use loom::sync::Arc;
use loom::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};

const EMPTY: u64 = 0;
const EXECUTING: u64 = 1;
const CLOSED: u64 = 2;
const TAG: u64 = 1 << 63;
const ID: u64 = u64::MAX - 1;
const READY: u64 = TAG | (ID >> 1);
const BIT: u64 = 1;
const SEALED: u64 = 2;

struct Epoch {
    source: AtomicU64,
    lane: AtomicU64,
    marked: AtomicBool,
    traversals: AtomicUsize,
}

impl Epoch {
    fn transfer(&self, early_clear: bool) {
        self.transfer_with_stop(early_clear, || {});
    }

    fn transfer_with_stop(&self, early_clear: bool, stop: impl FnOnce()) {
        if self.source.load(Acquire) & BIT == 0 {
            return;
        }
        let publish = || {
            matches!(
                self.lane.compare_exchange(EMPTY, READY, AcqRel, Acquire),
                Ok(_) | Err(READY)
            )
        };
        if early_clear {
            self.source.fetch_and(!BIT, AcqRel);
            stop();
            publish();
        } else if publish() {
            self.source.fetch_and(!BIT, AcqRel);
            stop();
        }
    }

    fn execute(&self) {
        if self
            .lane
            .compare_exchange(READY, EXECUTING, AcqRel, Acquire)
            .is_ok()
        {
            self.source.fetch_and(!BIT, AcqRel);
            if !self.marked.swap(true, AcqRel) {
                self.traversals.fetch_add(1, Release);
            }
            self.lane.store(EMPTY, Release);
        }
    }

    fn close(&self) {
        if matches!(
            self.source.compare_exchange(0, SEALED, AcqRel, Acquire),
            Ok(_) | Err(SEALED)
        ) && self
            .lane
            .compare_exchange(EMPTY, CLOSED, AcqRel, Acquire)
            .is_ok()
        {
            assert_eq!(self.traversals.load(Acquire), 1, "closed over untraced ID");
        }
    }
}

#[test]
fn full_width_identity_survives_parity_encoding() {
    for id in [1, 2, 3, TAG - 1, TAG, TAG + 1, u64::MAX - 2, u64::MAX - 1] {
        let word = TAG | (id >> 1);
        assert_eq!((word << 1) | (id & 1), id);
        assert!(word > CLOSED);
    }
}

#[test]
fn peers_can_finish_the_transfer_before_closure() {
    let early_clear = std::env::var_os("GC_CLEAR_BEFORE_LANE").is_some();
    loom::model(move || {
        let epoch = Arc::new(Epoch {
            source: AtomicU64::new(BIT),
            lane: AtomicU64::new(EMPTY),
            marked: AtomicBool::new(false),
            traversals: AtomicUsize::new(0),
        });
        let peer = epoch.clone();
        let selector = loom::thread::spawn(move || peer.transfer(early_clear));
        epoch.transfer(early_clear);
        epoch.execute();
        epoch.close();
        selector.join().unwrap();
        epoch.transfer(early_clear);
        epoch.execute();
        epoch.close();
        assert_eq!(epoch.lane.load(Acquire), CLOSED);
        assert_eq!(epoch.traversals.load(Acquire), 1);
    });
}

#[test]
fn ready_lane_remains_helpable_after_source_seals() {
    loom::model(|| {
        let epoch = Epoch {
            source: AtomicU64::new(SEALED),
            lane: AtomicU64::new(READY),
            marked: AtomicBool::new(false),
            traversals: AtomicUsize::new(0),
        };
        epoch.close();
        assert_eq!(epoch.lane.load(Acquire), READY);
        epoch.execute();
        epoch.close();
        assert_eq!(epoch.lane.load(Acquire), CLOSED);
    });
}

#[test]
fn source_removal_leaves_work_visible_to_a_peer() {
    let early_clear = std::env::var_os("GC_CLEAR_BEFORE_LANE").is_some();
    loom::model(move || {
        let epoch = Epoch {
            source: AtomicU64::new(BIT),
            lane: AtomicU64::new(EMPTY),
            marked: AtomicBool::new(false),
            traversals: AtomicUsize::new(0),
        };
        // Execute this peer's full turn at the destructive cut, before
        // resuming the selector. No scheduling or fairness assumption.
        epoch.transfer_with_stop(early_clear, || {
            epoch.transfer(false);
            epoch.execute();
            epoch.close();
            assert_eq!(epoch.lane.load(Acquire), CLOSED);
        });
    });
}
