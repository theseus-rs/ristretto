
#[cfg(all(test,not(target_family="wasm")))]
mod numeric_overflow_counts {
    use super::*;
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool,AtomicUsize,Ordering::Relaxed};
    struct Counter;
    #[global_allocator]
    static COUNTING:Counter=Counter;
    static ENABLED:AtomicBool=AtomicBool::new(false);
    static CALLS:AtomicUsize=AtomicUsize::new(0);
    static BYTES:AtomicUsize=AtomicUsize::new(0);
    static RELEASED:AtomicUsize=AtomicUsize::new(0);
    fn add(n:usize) {if ENABLED.load(Relaxed){CALLS.fetch_add(1,Relaxed); BYTES.fetch_add(n,Relaxed);}}
    fn freed(n:usize) {if ENABLED.load(Relaxed){RELEASED.fetch_add(n,Relaxed);}}
    // SAFETY: all operations forward the exact pointer, layout and size to System.
    unsafe impl GlobalAlloc for Counter {
      unsafe fn alloc(&self,l:Layout)->*mut u8 {add(l.size());unsafe{System.alloc(l)}}
      unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {add(l.size());unsafe{System.alloc_zeroed(l)}}
      unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {add(n);freed(l.size());unsafe{System.realloc(p,l,n)}}
      unsafe fn dealloc(&self,p:*mut u8,l:Layout){freed(l.size());unsafe{System.dealloc(p,l)}}
    }
    #[test]
    fn measure_numeric_barrier_allocations() -> Result<()> {
        let n=std::env::var("GC_COUNT_CHILDREN").unwrap().parse::<u64>().unwrap();
        let counted=std::env::var("GC_COUNT_POLICY").unwrap()=="1";
        let gc=GarbageCollector::with_config(Configuration::builder().threads(0).concurrent_publication(counted)
          .old_collection_interval(4).barrier_buffer_size(1).promotion_age(1).incremental_step_size(1)
          .max_pause_time_us(0).allocation_threshold(usize::MAX).build());
        let mut cs=Vec::new();
        for i in 0..n { for _ in 0..64 { crate::ObjectId::allocate()?; } cs.push(Gc::try_new(&gc,i)?.into_rooted()); }
        let owner=Gc::try_new(&gc,cs)?;
        gc.collect_full()?;gc.collect_old();
        assert!((0..200_000).any(|_|{gc.step();lock(&gc.domains[1].cycle).phase==Phase::Mark}));
        let epoch=gc.domains[1].mark_queue.birth_epoch().expect("old inbox");assert!(epoch.old_only);
        let context=gc.register_context();
        let managed=gc.managed_bytes();
        for pass in 0..8 {
          let lo=epoch.proposal_count();
          for c in [&CALLS,&BYTES,&RELEASED]{c.store(0,Relaxed);}
          let start=std::time::Instant::now();ENABLED.store(true,Relaxed);
          context.with(|| {for child in owner.iter(){gc.write_barrier(child);}});
          ENABLED.store(false,Relaxed);
          let nanos=start.elapsed().as_nanos();let hi=epoch.proposal_count();
          assert_eq!(gc.managed_bytes(),managed);
          eprintln!("PROBE {n} {counted} {pass} {} {} {} {nanos} {lo} {hi}",CALLS.load(Relaxed),BYTES.load(Relaxed),RELEASED.load(Relaxed));
        }
        let end=owner.last().unwrap();let weak=crate::GcWeak::new(end,crate::ReferenceKind::Weak,0);
        gc.collect_full()?;assert!(weak.refers_to(end));
        drop(owner);gc.collect_full()?;assert!(weak.upgrade().is_none());assert_eq!(gc.managed_bytes(),0);
        Ok(())
    }
}
